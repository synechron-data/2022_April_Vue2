<template>
  <home-component />
</template>

<script>
import HomeComponent from "../components/home/HomeComponent.vue";
export default {
  components: { HomeComponent },
  name: "HomeView",
};
</script>
