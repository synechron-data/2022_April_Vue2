import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/HomeView.vue'
import AboutView from '../views/AboutView.vue'
import ProductsView from '../views/ProductsView.vue'
import ProductDetails from '../components/products/ProductDetails.vue';
import ProductNotSelected from '../components/products/ProductNotSelected.vue';
import AdminView from '../views/AdminView.vue';
import LoginComponent from '../components/login/LoginComponent.vue';
import ViewNotFound from '../views/ViewNotFound.vue';
import authenticator from '@/services/authenticator'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'Home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'About',
    component: AboutView
  },
  {
    path: '/products',
    component: ProductsView,
    children: [
      {
        path: ':productId',
        name: 'ProductIdLink',
        component: ProductDetails
      },
      {
        path: '',
        component: ProductNotSelected
      }
    ]
  },
  {
    path: '/login',
    name: 'Login',
    component: LoginComponent
  },
  {
    path: '/admin',
    name: 'Admin',
    component: AdminView,
    beforeEnter: (to, from, next) => {
      if (!authenticator.isAuthenticated) {
        next({
          name: "Login",
          query: { redirectFrom: to.fullPath }
        });
      } else {
        next();
      }
    }
  },
  {
    path: '*',
    component: ViewNotFound
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
