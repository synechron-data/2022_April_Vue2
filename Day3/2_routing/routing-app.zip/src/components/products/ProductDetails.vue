<template>
	<div class="outerdiv">
		<div class="innerdiv">
			<h2 class="text-warning">Product Details</h2>
            <div v-if="product">
                <h3>{{ product.name }}</h3>
                <p>{{ product.description }}</p>
                <hr />
                <h4>{{ product.status }}</h4>
            </div>
            <div v-else>
                <h4 class="text-danger">Product Not Found</h4>
            </div>
		</div>
	</div>
</template>

<script>
	import productInMemoryClient from "../../services/product-in-memory-client";

	export default {
		name: "ProductDetailsComponent",
        data: function () {
			return {
				product: null,
			};
		},
        created() {
			this.loadProduct();
		},
        methods: {
            loadProduct() {
                this.product = productInMemoryClient.getProductById(
                    this.$route.params.productId
                );
            }
        },
        watch: {
            "$route.params.productId": function(newValue, oldValue) {
                if(newValue!==oldValue) {
                    this.loadProduct();
                }
            }
        }
	};
</script>