<template>
	<div>
		<h1 class="text-info text-center">Login Component</h1>
		<div class="row mt-5">
			<div class="col-6 offset-3">
				<h4 class="alert alert-danger" v-if="message">{{ message }}</h4>
				<b-form autocomplete="off" @submit.prevent="login" @reset="onReset">
					<b-form-group id="input-group-1" label="Username" label-for="input-1">
						<b-form-input
							id="input-1"
							v-model="user.username"
							type="text"
							placeholder="Enter Username"
						></b-form-input>
					</b-form-group>
					<b-form-group id="input-group-2" label="Password" label-for="input-2">
						<b-form-input
							id="input-2"
							v-model="user.password"
							type="password"
							placeholder="Enter Password"
						></b-form-input>
					</b-form-group>
					<div class="row">
						<div class="col">
							<b-button block type="submit" variant="primary">Login</b-button>
						</div>
						<div class="col">
							<b-button block type="reset" variant="outline-warning"
								>Reset</b-button
							>
						</div>
					</div>
				</b-form>
			</div>
		</div>
	</div>
</template>

<script>
	import authenticator from "../../services/authenticator";
	export default {
		name: "LoginComponent",
		data: function () {
			return {
				user: {
					username: "",
					password: "",
				},
				message: "",
				errorMsg: "",
				from: "",
			};
		},
		methods: {
			login() {
				authenticator
					.login(this.user.username, this.user.password)
					.then(() => {
						this.$router.push(this.from);
					})
					.catch((eMsg) => {
						this.message = eMsg;
					});
			},
			onReset() {
				this.user = { username: "", password: "" };
				this.message = "";
			},
		},
		beforeRouteEnter(to, from, next) {
			if (to.query.redirectFrom) {
				next((vm) => {
					vm.from = to.query.redirectFrom;
				});
			} else {
				next();
			}
		},
	};
</script>