// import authenticator from "./authenticator";

const url = process.env.VUE_APP_PRODUCT_API_URI;
console.log(url);

const productApiClient = {
    getAllProducts: function () {
        return new Promise((resolve, reject) => {
            let fData = {
                method: "GET",
                headers: {
                    "accept": "application/json",
                    // "x-access-token": authenticator.getToken()
                }
            };

            fetch(url, fData).then((response) => {
                response.json().then((result) => {
                    if (result.success)
                        resolve(result.data);
                    else
                        reject(result.message);
                }).catch((err) => {
                    console.error(err);
                    reject("Parsing Error...");
                });
            }).catch((err) => {
                console.error(err);
                reject("Communication Error...");
            });
        });
    }
};

export default productApiClient;
