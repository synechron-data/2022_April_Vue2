const url = process.env.VUE_APP_GET_TOKEN_URI;

const authenticator = {
    isAuthenticated: false,

    login: function (uname, pwd) {
        return new Promise((resolve, reject) => {
            var data = `username=${uname}&password=${pwd}`;

            let fData = {
                method: "POST",
                headers: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                body: data
            };

            fetch(url, fData).then((response) => {
                response.json().then((data) => {
                    if (data.success) {
                        window.sessionStorage.setItem("tk", data.token);
                        this.isAuthenticated = true;
                        resolve();
                    }
                    else
                        reject(data.message);
                }).catch((err) => {
                    console.error(err);
                    reject("Parsing Error...");
                });
            }).catch((err) => {
                console.error(err);
                reject("Communication Error...");
            });
        });
    },

    logout: function () {
        window.sessionStorage.removeItem("tk");
        this.isAuthenticated = false;
    },

    getToken: function () {
        return window.sessionStorage.getItem("tk");
    }
};

export default authenticator;