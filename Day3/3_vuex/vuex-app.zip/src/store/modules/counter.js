export default {
    state: {
        count: 0
    },
    mutations: {
        increment: function (state) {
            return state.count++;
        },
        decrement: function (state) {
            return state.count--;
        }
    }
}