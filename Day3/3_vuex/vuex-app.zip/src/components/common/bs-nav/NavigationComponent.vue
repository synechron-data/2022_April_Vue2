<template>
	<div>
		<nav class="navbar navbar-expand-sm navbar-dark bg-secondary fixed-top">
			<router-link class="navbar-brand" to="/">
				<img
					src="../../../assets/logo.png"
					className="d-inline-block align-top"
					alt="Vue Vuex"
					height="30"
					width="30"
				/>
				Vue Vuex
			</router-link>
			<button
				class="navbar-toggler"
				type="button"
				data-toggle="collapse"
				data-target="#navbarText"
				aria-controls="navbarText"
				aria-expanded="false"
				aria-label="Toggle navigation"
			>
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarText">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item px-3">
						<router-link exact class="nav-link" to="/home">Home</router-link>
					</li>
					<li class="nav-item px-3">
						<router-link class="nav-link" to="/about">About</router-link>
					</li>
					<li class="nav-item px-3">
						<router-link class="nav-link" to="/counter">Counter</router-link>
					</li>
					<li class="nav-item px-3">
						<router-link class="nav-link" to="/products">Products</router-link>
					</li>
				</ul>
				<ul class="navbar-nav ml-auto">
					<li class="nav-item px-3">
						<router-link class="nav-link" to="/signup"> SignUp </router-link>
					</li>
					<li class="nav-item px-3">
						<router-link class="nav-link" to="/login"> Login </router-link>
					</li>
				</ul>
			</div>
		</nav>
	</div>
</template>

<script>
	export default {
		name: "NavigationComponent",
	};
</script>

<style>
    body{
        margin-top: 60px;
    }

    nav li a:hover {
        font-weight: bold;
		background-color: indianred;
		cursor: pointer;
    }

    nav li a.router-link-active,
    nav li a.router-link-exact-active {
        border-radius: 15px;
        font-weight: bold;
        text-transform: uppercase;
		background-color: yellowgreen;
		cursor: pointer;
    }
</style>