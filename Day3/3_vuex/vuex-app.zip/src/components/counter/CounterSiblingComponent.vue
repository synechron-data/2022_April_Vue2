<template>
    <div>
        <div class="text-center">
            <h3 class="text-success">Counter Sibling Component</h3>
        </div>
        
        <div class="text-center">
            <h3>Count: {{ count }}</h3>
        </div>

        <div class="row">
            <div class="col">
                <button class="btn btn-success btn-block" @click="inc">
                    +
                </button>
            </div>
            <div class="col">
                <button class="btn btn-success btn-block" @click="dec">
                    -
                </button>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "CounterSiblingComponent",
        computed: {
            count() {
                // return this.$store.state.count; 
                return this.$store.state.counter.count; 
            }
        },
        methods: {
            inc() {
                this.$store.commit('increment');
            },
            dec() {
                this.$store.commit('decrement');
            }
        },
    }
</script>