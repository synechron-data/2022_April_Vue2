<template>
  <div>
    <Table :items="products" />
  </div>
</template>

<script>
import Table from "../common/datatable/Table.vue";
import { mapState, mapActions } from "vuex";

export default {
  name: "ProductsComponent",
  computed: {
    ...mapState({ products: (state) => state.products.items }),
  },
  async created() {
      await this.getProductsAction();
  },
  methods: {
      ...mapActions(["getProductsAction"])
  },
  components: { Table },
};
</script>