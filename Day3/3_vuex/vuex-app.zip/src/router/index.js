import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/HomeView.vue'
import AboutView from '../views/AboutView.vue'
import CounterView from '../views/CounterView.vue'
import ProductsView from '../views/ProductsView.vue'
import ViewNotFound from '../views/ViewNotFound.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'Home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'About',
    component: AboutView
  },
  {
    path: '/counter',
    component: CounterView,
  },
  {
    path: '/products',
    component: ProductsView,
  },
  {
    path: '*',
    component: ViewNotFound
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
