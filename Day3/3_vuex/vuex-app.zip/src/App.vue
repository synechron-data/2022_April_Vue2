<template>
  <div class="container">
    <navigation-component />
    <div class="mt-5">
      <router-view />
    </div>
  </div>
</template>

<script>
import NavigationComponent from "./components/common/bs-nav/NavigationComponent.vue";
export default {
  name: "AppComponent",
  components: { NavigationComponent },
};
</script>