<template>
    <div>
        <counter-component />
        <br>
        <counter-sibling-component />
    </div>
</template>

<script>
    import CounterComponent from '../components/counter/CounterComponent.vue'
    import CounterSiblingComponent from '../components/counter/CounterSiblingComponent.vue'
    export default {
    components: { CounterComponent, CounterSiblingComponent },
		name: "CounterView",
        
    }
</script>