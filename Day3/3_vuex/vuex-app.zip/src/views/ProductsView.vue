<template>
    <div>
		<products-component />
    </div>
</template>

<script>
    import ProductsComponent from '../components/products/ProductsComponent.vue'
    export default {
        components: { ProductsComponent },
        name: "ProductsView",
    }
</script>
