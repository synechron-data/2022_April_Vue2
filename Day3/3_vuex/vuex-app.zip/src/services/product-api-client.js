
const url = process.env.VUE_APP_PRODUCT_API_URI;

const productApiClient = {
    getAllProducts: function () {
        return new Promise((resolve, reject) => {
            fetch(url).then((response) => {
                response.json().then((result) => {
                    resolve(result);
                }).catch((err) => {
                    console.error(err);
                    reject("Parsing Error...");
                });
            }).catch((err) => {
                console.error(err);
                reject("Communication Error...");
            });
        });
    }
};

export default productApiClient;
