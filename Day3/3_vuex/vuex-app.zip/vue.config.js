const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  devServer: {
    host: 'localhost',
    open: {
      app: {
        name: 'chrome',
      },
    },
    port: 3001
  }
})
