<template>
  <div class="container">
    <!-- <form-validation /> -->
    <ajax-component />
  </div>
</template>

<script>
  /* eslint-disable */
  import FormValidation from "./components/1_form-validation/FormValidation.vue";
  import AjaxComponent from "./components/2_ajax/AjaxComponent.vue";
  export default {
    components: { FormValidation, AjaxComponent },
    name: "AppComponent",
  };
</script>