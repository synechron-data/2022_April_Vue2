<template>
  <div class="container">
    <!-- <component-one />
    <component-two /> -->

    <!-- <component-with-data /> -->
    <!-- <prop-root /> -->
    <!-- <behavior-root /> -->
    <!-- <event-component /> -->
    <!-- <binding-component /> -->
    <!-- <calculator-assignment /> -->
    <!-- <counter-assignment /> -->
    <!-- <slot-root /> -->
    <!-- <filter-demo /> -->
    <!-- <custom-directives /> -->
    <!-- <mixin-root /> -->
    <dynamic-root />
  </div>
</template>

<script>
/* eslint-disable */
// import ComponentOne from "./components/1_components-with-css-modules/ComponentOne.vue";
// import ComponentTwo from './components/1_components-with-css-modules/ComponentTwo.vue';

// import ComponentOne from "./components/2_external-css/comp-one/ComponentOne.vue";
// import ComponentTwo from "./components/2_external-css/comp-two/ComponentTwo.vue";

import ComponentOne from "./components/3_external-css-as-css-modules/comp-one/ComponentOne.vue";
import ComponentTwo from "./components/3_external-css-as-css-modules/comp-two/ComponentTwo.vue";
import ComponentWithData from "./components/4_comp-data/ComponentWithData.vue";
import PropRoot from "./components/5_comp-props/PropRoot.vue";
import BehaviorRoot from "./components/6_comp-methods/BehaviorRoot.vue";
import EventComponent from "./components/7_event-handling/EventComponent.vue";
import BindingComponent from "./components/8_two-way-binding/BindingComponent.vue";
import CalculatorAssignment from "./components/9_calculator-assignment/CalculatorAssignment.vue";
import CounterAssignment from "./components/10_counter-assignment/CounterAssignment.vue";
import SlotRoot from "./components/11_slots/SlotRoot.vue";
import FilterDemo from "./components/12_filters/FilterDemo.vue";
import CustomDirectives from "./components/13_custom-directives/CustomDirectives.vue";
import MixinRoot from "./components/14_mixins/MixinRoot.vue";
import DynamicRoot from './components/15_dynamic-components/DynamicRoot.vue';

export default {
  components: {
    ComponentOne,
    ComponentTwo,
    ComponentWithData,
    PropRoot,
    BehaviorRoot,
    EventComponent,
    BindingComponent,
    CalculatorAssignment,
    CounterAssignment,
    SlotRoot,
    FilterDemo,
    CustomDirectives,
    MixinRoot,
    DynamicRoot
  },
  name: "AppComponent",
};
</script>