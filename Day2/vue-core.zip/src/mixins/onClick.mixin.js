export default {
    methods: {
        onClick(value) {
            alert(`From Mixin - ${value}`);
        },
        handleClick(value) {
            alert(`From Mixin - ${value}`);
        },
    },
};