import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.scss';
import 'bootstrap';

import Vue from 'vue'
import AppComponent from './App.vue';
import demoDirective from './directives/demo.directive';
import changeContentDirective from './directives/changeContent.directive';
import highlightDirective from './directives/highlight.directive';

Vue.config.productionTip = false;

// Global Mixin
// Vue.mixin({
//   created: function () {
//     console.log("Vue Created...", this);
//   }
// });

// Global Filter
Vue.filter('JSON', function (value) {
  return JSON.stringify(value);
});

// Global Directives
Vue.directive('demo', demoDirective);
Vue.directive('cc', changeContentDirective);
Vue.directive('highlight', highlightDirective);

new Vue({
  render: (h) => h(AppComponent)
}).$mount("#app");