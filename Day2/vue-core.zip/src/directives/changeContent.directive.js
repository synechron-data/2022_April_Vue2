const changeContentDirective = {
    bind: function (el) {
        el.innerHTML = "Content Added by the Custom Directive";
    }
};

export default changeContentDirective;