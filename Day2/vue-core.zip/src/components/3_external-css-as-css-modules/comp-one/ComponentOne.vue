<template>
  <div>
    <h1 class="text-primary">Hello from Component One</h1>
    <h2 v-bind:class="styles.card">From Component One</h2>
  </div>
</template>

<script>
  import styles from "./ComponentOne.module.css";
  export default {
    name: "ComponentOne",
    data: function () {
      return {
        styles,
      };
    },
  };
</script>