<template>
  <div>
    <h1 class="text-success">Hello from Component Two</h1>
    <h2 v-bind:class="styles.card">From Component Two</h2>
  </div>
</template>

<script>
import styles from "./ComponentTwo.module.css";

export default {
  name: "ComponentTwo",
  data: function () {
    return {
      styles,
    };
  },
};
</script>