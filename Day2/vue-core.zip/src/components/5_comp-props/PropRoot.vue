<template>
  <div>
    <!-- <component-with-props
      v-bind:id="1"
      v-bind:name="'Manish'"
      v-bind:address="{ city: 'Pune', state: 'MH' }"
      v-bind:friends="fList"
    /> -->

    <component-with-props
      :id="id"
      :name="'Manish'"
      :address="{ city: 'Pune', state: 'MH' }"
      :friends="fList"
      :greet="
        () => {
          alert('From the Parent Component');
        }
      "
    />
  </div>
</template>

<script>
import ComponentWithProps from "./ComponentWithProps.vue";

export default {
  name: "PropRoot",
  components: { ComponentWithProps },
  data: function () {
    return {
      fList: ["Abhijeet", "Ramakant"],
      id: Symbol(1),
    };
  },
};
</script>