<template>
  <div>
    <h2 class="text-success text-center">Sibling Communication</h2>
    <h3 class="alert alert-danger mt-3 mb-3" v-if="message">{{ message }}</h3>

    <counter
      :interval="10"
      ref="c2"
      @flag-changed="handleFlagChanged"
      @count-changed="handleCountChanged"
    />

    <div class="mt-3 mb-3">
      <counter-sibling :current_count_via_prop="pcount" />
    </div>

    <div class="d-grid gap-2 mx-auto col-6 mt-5">
      <button class="btn btn-warning" @click="p_reset">
        <span class="fs-4">Parent Reset</span>
      </button>
    </div>
  </div>

  <!-- <div>
    <h2 class="text-success text-center">Notify Parent from Child</h2>
    <h2 class="text-info text-center">
      Child to Parent Communication via Events
      <br />
      Vue components have a $emit() function that allows you to pass custom
      events up the component tree.
    </h2>
    <h3 class="alert alert-danger mt-3 mb-3" v-if="message">{{ message }}</h3>
    <counter :interval="10" ref="c1" v-on:flag-changed="handleFlagChanged" />
    <counter :interval="10" ref="c2" @flag-changed="handleFlagChanged" />
   
    <div class="d-grid gap-2 mx-auto col-6 mt-5">
      <button class="btn btn-warning" @click="p_reset">
        <span class="fs-4">Parent Reset</span>
      </button>
    </div>
  </div> -->

  <!-- <div>
    <h2 class="text-success text-center">Calling Parent Method from Child</h2>
    <h2 class="text-danger text-center">
      Passing Parent Method Reference to Child - Anti Pattern
    </h2>
    <h3 class="alert alert-danger mt-3 mb-3" v-if="message">{{ message }}</h3>
    <counter :interval="10" ref="c1" :onMax="updateMessage" />
    <div class="d-grid gap-2 mx-auto col-6 mt-5">
      <button class="btn btn-warning" @click="p_reset">
        <span class="fs-4">Parent Reset</span>
      </button>
    </div>
  </div> -->

  <!-- <div>
		<h2 class="text-success text-center">Calling Child Method from Parent</h2>
		<counter :interval="10" ref="c1" />
		<div class="d-grid gap-2 mx-auto col-6 mt-5">
			<button class="btn btn-warning" @click="p_reset">
				<span class="fs-4">Parent Reset</span>
			</button>
		</div>
	</div> -->

  <!-- <div>
		<counter />
		<counter :interval="10" />
	</div> -->
</template>

<script>
import Counter from "./Counter.vue";
import CounterSibling from "./CounterSibling.vue";

export default {
  name: "CounterAssignment",
  components: { Counter, CounterSibling },
  data() {
    return {
      message: "",
      pcount: 0,
    };
  },
  methods: {
    p_reset() {
      // console.log(this.$refs);
      // console.log(this.$refs.c1);
      this.$refs.c1.reset();
    },
    updateMessage(flag) {
      if (flag)
        this.message =
          "Max Click Reached, please click 'reset button' to restart";
      else this.message = "";
    },
    handleFlagChanged(flag) {
      if (flag)
        this.message =
          "Max Click Reached, please click 'reset button' to restart";
      else this.message = "";
    },
    handleCountChanged(count) {
      this.pcount = count;
    },
  },
};
</script>