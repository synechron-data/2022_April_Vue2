<template>
  <div>
    <div class="text-center">
      <h3 class="text-primary">Counter Component</h3>
    </div>
    <div class="d-grid gap-2 mx-auto col-6">
      <input
        type="text"
        class="form-control form-control-lg"
        v-model.number="count"
        :disabled="flag"
      />
      <button class="btn btn-primary" :disabled="flag" @click="inc">
        <span class="fs-4">+</span>
      </button>
      <button class="btn btn-primary" :disabled="flag" @click="dec">
        <span class="fs-4">-</span>
      </button>
      <button class="btn btn-secondary" :disabled="!flag" @click="reset">
        <span class="fs-4">Reset</span>
      </button>
    </div>
  </div>
</template>

<script>
import EventBus from "./EventBus";

export default {
  name: "CounterComponent",
  data() {
    this.clickCount = 0;
    return {
      count: 0,
      flag: false,
    };
  },
  props: {
    interval: {
      type: Number,
      default: 1,
    },
    onMax: {
      type: Function,
      default: function () {},
    },
  },
  methods: {
    manageClickCount() {
      this.clickCount += 1;
      if (this.clickCount > 9) {
        this.flag = true;
      }
    },
    inc() {
      this.manageClickCount();
      this.count += this.interval;
    },
    dec() {
      this.manageClickCount();
      this.count -= this.interval;
    },
    reset() {
      this.clickCount = 0;
      this.count = 0;
      this.flag = false;
    },
  },
  watch: {
    flag: function (newValue, oldValue) {
      //   console.log("new: ", newValue);
      //   console.log("old: ", oldValue);
      if (newValue !== oldValue) {
        // this.onMax(this.flag);
        this.$emit("flag-changed", this.flag);
      }
    },
    count: function (newValue, oldValue) {
      if (newValue !== oldValue) {
        this.$emit("count-changed", this.count);
        // console.log(this.$root);
        this.$root.$emit("root-count-changed", this.count);
        EventBus.$emit("count-published", this.count);
      }
    },
  },
};
</script>