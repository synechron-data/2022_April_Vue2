<template>
  <div class="container">
    <component-one />
    <component-two />
  </div>
</template>

<script>
// import ComponentOne from "./components/2_multi-components/ComponentOne.vue";
// import ComponentTwo from "./components/2_multi-components/ComponentTwo.vue";

// import ComponentOne from "./components/3_components-with-inline-style/ComponentOne.vue";
// import ComponentTwo from "./components/3_components-with-inline-style/ComponentTwo.vue";

// import ComponentOne from "./components/4_components-with-css-class/ComponentOne.vue";
// import ComponentTwo from "./components/4_components-with-css-class/ComponentTwo.vue";

import ComponentOne from "./components/5_components-with-css-class-scoped/ComponentOne.vue";
import ComponentTwo from "./components/5_components-with-css-class-scoped/ComponentTwo.vue";

export default {
  components: { ComponentOne, ComponentTwo },
  name: "AppComponent",
};
</script>