// import Vue from 'vue'
// Vue.config.productionTip = false

// Template Compilation is possible on Build, when we write single file component 
// By default cli projects are configured for runtime-only build, which does not include template compiler
// Enable runtimeCompiler: true in vue.config.js (Include Runtime and Compiler both in the build)
// This will be required when we write templates in string format
// new Vue({
//   el: '#app',
//   template: `
//     <h1>
//       Hello from Main Vue
//     </h1>
//   `
// });

// ------------------------------------------------- Global Component
// import Vue from 'vue'
// Vue.config.productionTip = false

// If you are registering a component using PascalCase name, you can use it as <PascalCase/> or <camelCase/> or <kebab-case/>
// Vue.component("GreetingComponent", {
//   template: `
//     <h1>
//       Hello from Global Greeting Component
//     </h1>
//   `
// });

// If you are registering a component using cascalCase name, you can use it as <camelCase/> or <kebab-case/>
// Vue.component("greetingComponent", {
//   template: `
//     <h1>
//       Hello from Global Greeting Component
//     </h1>
//   `
// });

// If you are registering a component using kebab-case name, you can use it as <kebab-case/>
// Vue.component("greeting-component", {
//   template: `
//     <h1>
//       Hello from Global Greeting Component
//     </h1>
//   `
// });

// If you are registering a component using smallcase name, you can use it only using <smallcase/>
// Prefer not to use it, as it throws error
// Vue.component("greetingcomponent", {
//   template: `
//     <h1>
//       Hello from Global Greeting Component
//     </h1>
//   `
// });

// new Vue({
//   el: '#app',
//   template: `
//     <div>
//       <GreetingComponent />
//       <greetingComponent />
//       <greeting-component />
//     </div>
//   `
// });

// // ------------------------------------------------- Local Component
// import Vue from 'vue'
// Vue.config.productionTip = false

// const GreetingComponent = {
//   template: `
//     <h1>
//       Hello from Greeting Component
//     </h1>
//   `
// };

// new Vue({
//   el: '#app',
//   template: `
//     <div>
//       <!-- <GreetingComponent />
//       <greetingComponent />
//       <greeting-component /> -->

//       <!-- Using Identifier -->
//       <GComp />
//       <gComp />
//       <g-comp />
//     </div>
//   `,
//   // components: { GreetingComponent }           // Local Component Registartion
//   components: { 'GComp': GreetingComponent }     // Local Component Registartion with Identifier
// });

// ---------------------------------------------------------- Loading Component from an external file
// import Vue from 'vue'
// import HelloComponent from './components/1_hello/HelloComponent.vue';

// Vue.config.productionTip = false;

// new Vue({
//   el: '#app',
//   template: `
//     <div>
//       <hello-component />
//     </div>
//   `,
//   components: {
//     'hello-component': HelloComponent
//   }
// });

// ---------------------------------------------------------- Pre Compiled Template
// import Vue from 'vue'
// import HelloComponent from './components/1_hello/HelloComponent.vue';

// Vue.config.productionTip = false;

// // var vm = new Vue({
// //   render: function(createElement) {
// //     return createElement(HelloComponent);
// //   }
// // });
// // vm.$mount("#app");

// // new Vue({
// //   render: function(createElement) {
// //     return createElement(HelloComponent);
// //   }
// // }).$mount("#app");

// // new Vue({
// //   render: (createElement) => createElement(HelloComponent)
// // }).$mount("#app");

// new Vue({
//   render: (h) => h(HelloComponent)
// }).$mount("#app");

// ------------------------------------------------- Using Bootstrap as Global CSS file
// npm i bootstrap bootstrap-icons

// import 'bootstrap/dist/css/bootstrap.css';
// import 'bootstrap-icons/font/bootstrap-icons.css';
// import 'bootstrap';

// To include .scss files
// npm i -D node-sass sass-loader
// import 'bootstrap/scss/bootstrap.scss';
// import 'bootstrap-icons/font/bootstrap-icons.scss';
// import 'bootstrap';

// import Vue from 'vue'
// import HelloComponent from './components/1_hello/HelloComponent.vue';

// Vue.config.productionTip = false;

// new Vue({
//   render: (h) => h(HelloComponent)
// }).$mount("#app");

// ----------------------------------------------------------  Multi Components
// import 'bootstrap/scss/bootstrap.scss';
// import 'bootstrap-icons/font/bootstrap-icons.scss';
// import 'bootstrap';

// import Vue from 'vue'
// import ComponentOne from './components/2_multi-components/ComponentOne.vue';
// import ComponentTwo from './components/2_multi-components/ComponentTwo.vue';

// Vue.config.productionTip = false;

// new Vue({
//   render: (h) => h(ComponentOne)
// }).$mount("#c1");

// new Vue({
//   render: (h) => h(ComponentTwo)
// }).$mount("#c2");

// ----------------------------------------------------------  One Root Component
import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.scss';
import 'bootstrap';

import Vue from 'vue'
import AppComponent from './App.vue';

Vue.config.productionTip = false;

new Vue({
  render: (h) => h(AppComponent)
}).$mount("#app");