<template>
  <h1 class="text-primary">Hello World! <i class="bi bi-activity"></i> </h1>
</template>

<script>
export default {
  name: "hello-world-component",
};
</script>